﻿namespace WinFormsLibraryLogic
{
    public class CalculatorLogic
    { 

        private int firstNumber;

        public int FirstNumber
        {
            get { return firstNumber; }
            set { firstNumber = value; }
        }

    }
}