﻿using System.Runtime.CompilerServices;

namespace WinFormsLibraryCalculatorLogic
{
	public class CalculatorLogic
	{
		private string firstNumber;

		public string FirstNumber
		{
			get { return firstNumber; }
			set { firstNumber = value; }
		}

		private string secondNumber;

		public string SecondNumber
		{
			get { return secondNumber; }
			set { secondNumber = value; }
		}

		private string action;

		public string Action
		{
			get { return action; }
			set { action = value; }
		}

        private string secondaryAction;

        public string SecondaryAction
        {
            get { return secondaryAction; }
            set { secondaryAction = value; }
        }




        public CalculatorLogic(string FirstNumber, string SecondNumber, string Action, string secondaryAction)
		{
			this.FirstNumber = FirstNumber;
			this.SecondNumber = SecondNumber;
			this.Action = Action;
			this.SecondaryAction = SecondaryAction;
		}

		public CalculatorLogic() : this(string.Empty, string.Empty, string.Empty, string.Empty)
		{
		}

		public double CalculatorActions()
		{
			Exception ex = new InvalidDataException("You cannot divide by 0.");
			double result = 0.0;
			bool error = false;
			double firstNum = double.Parse(firstNumber);
			double secondNum = double.Parse(secondNumber);
			string chosenAction = action;
			string secondaryAction = SecondaryAction;
			switch (chosenAction)
			{
				case "+":
					{
						result = firstNum + secondNum;
						break;
					}
				case "-":
					{
						result = firstNum - secondNum;
						break;
					}
				case "*":
					{
						result = firstNum * secondNum;
						break;
					}
                case "/":
                    {
						if (secondNum != 0)
						{
							result = firstNum / secondNum;
						}
						else
						{
							error = true;
						    result = 0.0;
						}
						break;
				    }
				case "1/x":
					{
						result = 1 / secondNum;
						break;
					}
				case "%":
					{
						if (secondaryAction == "+")
						{
							result = firstNum + (firstNum * secondNum / 100);
						}
						else if(secondaryAction == "-")
						{
							result = firstNum - (firstNum * secondNum / 100);
						}
						else if (secondaryAction == "*")
						{
							result = firstNum * (firstNum * secondNum / 100);
						}
						else if (secondaryAction == "/")
						{
							result = firstNum / (firstNum * secondNum / 100);
						}
						break;
					}
				case "^2":
					{
						result = firstNum * secondNum;
						break;
					}
				case "2/-":
					{
						result = Math.Sqrt(firstNum);
						break;
					}
			}
			
			return result;
		}
	}
}