using System.Text;
using WinFormsLibraryCalculatorLogic;

namespace WinFormsAppCalculator
{
    public partial class CalculatorForm : Form
    {
        CalculatorLogic logic;
        private string firstNumber;
        private string secondNumber;
        private string action;
        private string secondaryAction;
        public CalculatorForm()
        {
            InitializeComponent();
            logic = new CalculatorLogic();
            firstNumber = string.Empty;
            secondNumber = string.Empty;
            action = string.Empty;
            secondaryAction = string.Empty;
        }

        public void EmptyResultTextBox()
        {
            if (resultTextBox.Text == "0")
            {
                resultTextBox.Text = string.Empty;
            }
        }

        private void oneButton_Click(object sender, EventArgs e)
        {
            EmptyResultTextBox();
            resultTextBox.Text = resultTextBox.Text + "1";
        }

        private void twoButton_Click(object sender, EventArgs e)
        {
            EmptyResultTextBox();
            resultTextBox.Text = resultTextBox.Text + "2";
        }

        private void threeButton_Click(object sender, EventArgs e)
        {
            EmptyResultTextBox();
            resultTextBox.Text = resultTextBox.Text + "3";
        }

        private void fourButton_Click(object sender, EventArgs e)
        {
            EmptyResultTextBox();
            resultTextBox.Text = resultTextBox.Text + "4";
        }

        private void fiveButton_Click(object sender, EventArgs e)
        {
            EmptyResultTextBox();
            resultTextBox.Text = resultTextBox.Text + "5";
        }

        private void sixButton_Click(object sender, EventArgs e)
        {
            EmptyResultTextBox();
            resultTextBox.Text = resultTextBox.Text + "6";
        }

        private void sevenButton_Click(object sender, EventArgs e)
        {
            EmptyResultTextBox();
            resultTextBox.Text = resultTextBox.Text + "7";
        }

        private void eightButton_Click(object sender, EventArgs e)
        {
            EmptyResultTextBox();
            resultTextBox.Text = resultTextBox.Text + "8";
        }

        private void nineButton_Click(object sender, EventArgs e)
        {
            EmptyResultTextBox();
            resultTextBox.Text = resultTextBox.Text + "9";
        }

        private void buttonMinus_Click(object sender, EventArgs e)
        {
            this.firstNumber = resultTextBox.Text;
            resultTextBox.Text = string.Empty;

            this.action = "-";
            this.secondaryAction = "-";
        }

        private void buttonPlus_Click(object sender, EventArgs e)
        {
            this.firstNumber = resultTextBox.Text;
            resultTextBox.Text = string.Empty;

            this.action = "+";
            this.secondaryAction = "+";
        }

        private void zeroButton_Click(object sender, EventArgs e)
        {
            if (resultTextBox.Text == "0")
            {

            }
            else
            {
                resultTextBox.Text += "0";
            }
        }

        private void buttonC_Click(object sender, EventArgs e)
        {
            resultTextBox.Text = string.Empty + "0";
        }

        private void CalculatorForm_Load(object sender, EventArgs e)
        {
            resultTextBox.Text = string.Empty + "0";

        }

        private void buttonResult_Click(object sender, EventArgs e)
        {
            this.secondNumber = resultTextBox.Text;
            logic = new CalculatorLogic(firstNumber, secondNumber, action, secondaryAction);
            resultTextBox.Text = (logic.CalculatorActions().ToString());
        }

        private void buttonCE_Click(object sender, EventArgs e)
        {
            if (this.secondNumber != null)
            {
                this.secondNumber = string.Empty;
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            this.firstNumber = resultTextBox.Text;
            resultTextBox.Text = string.Empty;

            this.action = "*";
            this.secondaryAction = "*";
        }

        private void buttonDivide_Click(object sender, EventArgs e)
        {
            this.firstNumber = resultTextBox.Text;
            resultTextBox.Text = string.Empty;

            this.action = "/";
            this.secondaryAction= "/";
        }

        private void buttonXDivByItself_Click(object sender, EventArgs e)
        {
            this.firstNumber = resultTextBox.Text;
            this.secondNumber = "0";
            

            this.action = "2/-";
            


        }

        private void button1DivByX_Click(object sender, EventArgs e)
        {
            this.firstNumber = "0";
            this.secondNumber = resultTextBox.Text;
            resultTextBox.Text = string.Empty;

            this.action = "1/x";

            logic = new CalculatorLogic(firstNumber, secondNumber, action, secondaryAction);
            resultTextBox.Text = (logic.CalculatorActions().ToString());

        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            if (resultTextBox.Text != string.Empty)
            {
                StringBuilder sb = new StringBuilder(resultTextBox.Text);
                sb.Remove(resultTextBox.Text.Length - 1, 1);
                resultTextBox.Text = sb.ToString();
            }
        }

        private void buttonPercent_Click(object sender, EventArgs e)
        {
            if (this.firstNumber == null)
            {
                this.firstNumber = resultTextBox.Text;
            }

            if (firstNumber != null)
            {
                this.secondNumber = resultTextBox.Text;
                
            }

            if (resultTextBox.Text == secondNumber)
            {
                this.action = "%";
                logic = new CalculatorLogic(firstNumber, secondNumber, action, secondaryAction);
                resultTextBox.Text = (logic.CalculatorActions().ToString());
            }
            
        }

        private void buttonXUpOn2_Click(object sender, EventArgs e)
        {
            this.firstNumber = resultTextBox.Text;
            this.secondNumber = resultTextBox.Text;

            this.action = "^2";

            logic = new CalculatorLogic(firstNumber, secondNumber, action, secondaryAction);
            resultTextBox.Text = (logic.CalculatorActions().ToString());
        }

        private void buttonPlusSlashMinus_Click(object sender, EventArgs e)
        {
            this.firstNumber = resultTextBox.Text;
        }
    }
}