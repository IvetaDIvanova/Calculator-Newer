﻿namespace WinFormsAppCalculator
{
    partial class CalculatorForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            buttonResult = new Button();
            buttonComma = new Button();
            zeroButton = new Button();
            buttonPlusSlashMinus = new Button();
            buttonMinus = new Button();
            threeButton = new Button();
            twoButton = new Button();
            oneButton = new Button();
            buttonPlus = new Button();
            sixButton = new Button();
            fiveButton = new Button();
            fourButton = new Button();
            buttonAdd = new Button();
            nineButton = new Button();
            eightButton = new Button();
            sevenButton = new Button();
            buttonDivide = new Button();
            buttonXDivByItself = new Button();
            buttonXUpOn2 = new Button();
            button1DivByX = new Button();
            buttonRemove = new Button();
            buttonC = new Button();
            buttonCE = new Button();
            resultTextBox = new TextBox();
            buttonPercent = new Button();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Controls.Add(buttonResult, 3, 6);
            tableLayoutPanel1.Controls.Add(buttonComma, 2, 6);
            tableLayoutPanel1.Controls.Add(zeroButton, 1, 6);
            tableLayoutPanel1.Controls.Add(buttonPlusSlashMinus, 0, 6);
            tableLayoutPanel1.Controls.Add(buttonMinus, 3, 5);
            tableLayoutPanel1.Controls.Add(threeButton, 2, 5);
            tableLayoutPanel1.Controls.Add(twoButton, 1, 5);
            tableLayoutPanel1.Controls.Add(oneButton, 0, 5);
            tableLayoutPanel1.Controls.Add(buttonPlus, 3, 4);
            tableLayoutPanel1.Controls.Add(sixButton, 2, 4);
            tableLayoutPanel1.Controls.Add(fiveButton, 1, 4);
            tableLayoutPanel1.Controls.Add(fourButton, 0, 4);
            tableLayoutPanel1.Controls.Add(buttonAdd, 3, 3);
            tableLayoutPanel1.Controls.Add(nineButton, 2, 3);
            tableLayoutPanel1.Controls.Add(eightButton, 1, 3);
            tableLayoutPanel1.Controls.Add(sevenButton, 0, 3);
            tableLayoutPanel1.Controls.Add(buttonDivide, 3, 2);
            tableLayoutPanel1.Controls.Add(buttonXDivByItself, 2, 2);
            tableLayoutPanel1.Controls.Add(buttonXUpOn2, 1, 2);
            tableLayoutPanel1.Controls.Add(button1DivByX, 0, 2);
            tableLayoutPanel1.Controls.Add(buttonRemove, 3, 1);
            tableLayoutPanel1.Controls.Add(buttonC, 2, 1);
            tableLayoutPanel1.Controls.Add(buttonCE, 1, 1);
            tableLayoutPanel1.Controls.Add(resultTextBox, 0, 0);
            tableLayoutPanel1.Controls.Add(buttonPercent, 0, 1);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 7;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 22F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 13F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 13F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 13F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 13F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 13F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 13F));
            tableLayoutPanel1.Size = new Size(382, 520);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // buttonResult
            // 
            buttonResult.BackColor = Color.White;
            buttonResult.Dock = DockStyle.Fill;
            buttonResult.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            buttonResult.Location = new Point(288, 452);
            buttonResult.Name = "buttonResult";
            buttonResult.Size = new Size(91, 65);
            buttonResult.TabIndex = 24;
            buttonResult.Text = "=";
            buttonResult.UseVisualStyleBackColor = false;
            buttonResult.Click += buttonResult_Click;
            // 
            // buttonComma
            // 
            buttonComma.BackColor = Color.White;
            buttonComma.Dock = DockStyle.Fill;
            buttonComma.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            buttonComma.Location = new Point(193, 452);
            buttonComma.Name = "buttonComma";
            buttonComma.Size = new Size(89, 65);
            buttonComma.TabIndex = 23;
            buttonComma.Text = ",";
            buttonComma.UseVisualStyleBackColor = false;
            // 
            // zeroButton
            // 
            zeroButton.BackColor = Color.White;
            zeroButton.Dock = DockStyle.Fill;
            zeroButton.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            zeroButton.Location = new Point(98, 452);
            zeroButton.Name = "zeroButton";
            zeroButton.Size = new Size(89, 65);
            zeroButton.TabIndex = 22;
            zeroButton.Text = "0";
            zeroButton.UseVisualStyleBackColor = false;
            zeroButton.Click += zeroButton_Click;
            // 
            // buttonPlusSlashMinus
            // 
            buttonPlusSlashMinus.BackColor = Color.White;
            buttonPlusSlashMinus.Dock = DockStyle.Fill;
            buttonPlusSlashMinus.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            buttonPlusSlashMinus.Location = new Point(3, 452);
            buttonPlusSlashMinus.Name = "buttonPlusSlashMinus";
            buttonPlusSlashMinus.Size = new Size(89, 65);
            buttonPlusSlashMinus.TabIndex = 21;
            buttonPlusSlashMinus.Text = "+/-";
            buttonPlusSlashMinus.UseVisualStyleBackColor = false;
            buttonPlusSlashMinus.Click += buttonPlusSlashMinus_Click;
            // 
            // buttonMinus
            // 
            buttonMinus.BackColor = Color.White;
            buttonMinus.Dock = DockStyle.Fill;
            buttonMinus.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            buttonMinus.Location = new Point(288, 385);
            buttonMinus.Name = "buttonMinus";
            buttonMinus.Size = new Size(91, 61);
            buttonMinus.TabIndex = 20;
            buttonMinus.Text = "-";
            buttonMinus.UseVisualStyleBackColor = false;
            buttonMinus.Click += buttonMinus_Click;
            // 
            // threeButton
            // 
            threeButton.BackColor = Color.White;
            threeButton.Dock = DockStyle.Fill;
            threeButton.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            threeButton.Location = new Point(193, 385);
            threeButton.Name = "threeButton";
            threeButton.Size = new Size(89, 61);
            threeButton.TabIndex = 19;
            threeButton.Text = "3";
            threeButton.UseVisualStyleBackColor = false;
            threeButton.Click += threeButton_Click;
            // 
            // twoButton
            // 
            twoButton.BackColor = Color.White;
            twoButton.Dock = DockStyle.Fill;
            twoButton.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            twoButton.Location = new Point(98, 385);
            twoButton.Name = "twoButton";
            twoButton.Size = new Size(89, 61);
            twoButton.TabIndex = 18;
            twoButton.Text = "2";
            twoButton.UseVisualStyleBackColor = false;
            twoButton.Click += twoButton_Click;
            // 
            // oneButton
            // 
            oneButton.BackColor = Color.White;
            oneButton.Dock = DockStyle.Fill;
            oneButton.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            oneButton.Location = new Point(3, 385);
            oneButton.Name = "oneButton";
            oneButton.Size = new Size(89, 61);
            oneButton.TabIndex = 17;
            oneButton.Text = "1";
            oneButton.UseVisualStyleBackColor = false;
            oneButton.Click += oneButton_Click;
            // 
            // buttonPlus
            // 
            buttonPlus.BackColor = Color.White;
            buttonPlus.Dock = DockStyle.Fill;
            buttonPlus.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            buttonPlus.Location = new Point(288, 318);
            buttonPlus.Name = "buttonPlus";
            buttonPlus.Size = new Size(91, 61);
            buttonPlus.TabIndex = 16;
            buttonPlus.Text = "+";
            buttonPlus.UseVisualStyleBackColor = false;
            buttonPlus.Click += buttonPlus_Click;
            // 
            // sixButton
            // 
            sixButton.BackColor = Color.White;
            sixButton.Dock = DockStyle.Fill;
            sixButton.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            sixButton.Location = new Point(193, 318);
            sixButton.Name = "sixButton";
            sixButton.Size = new Size(89, 61);
            sixButton.TabIndex = 15;
            sixButton.Text = "6";
            sixButton.UseVisualStyleBackColor = false;
            sixButton.Click += sixButton_Click;
            // 
            // fiveButton
            // 
            fiveButton.BackColor = Color.White;
            fiveButton.Dock = DockStyle.Fill;
            fiveButton.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            fiveButton.Location = new Point(98, 318);
            fiveButton.Name = "fiveButton";
            fiveButton.Size = new Size(89, 61);
            fiveButton.TabIndex = 14;
            fiveButton.Text = "5";
            fiveButton.UseVisualStyleBackColor = false;
            fiveButton.Click += fiveButton_Click;
            // 
            // fourButton
            // 
            fourButton.BackColor = Color.White;
            fourButton.Dock = DockStyle.Fill;
            fourButton.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            fourButton.Location = new Point(3, 318);
            fourButton.Name = "fourButton";
            fourButton.Size = new Size(89, 61);
            fourButton.TabIndex = 13;
            fourButton.Text = "4";
            fourButton.UseVisualStyleBackColor = false;
            fourButton.Click += fourButton_Click;
            // 
            // buttonAdd
            // 
            buttonAdd.BackColor = Color.White;
            buttonAdd.Dock = DockStyle.Fill;
            buttonAdd.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            buttonAdd.Location = new Point(288, 251);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(91, 61);
            buttonAdd.TabIndex = 12;
            buttonAdd.Text = "*";
            buttonAdd.UseVisualStyleBackColor = false;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // nineButton
            // 
            nineButton.BackColor = Color.White;
            nineButton.Dock = DockStyle.Fill;
            nineButton.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            nineButton.Location = new Point(193, 251);
            nineButton.Name = "nineButton";
            nineButton.Size = new Size(89, 61);
            nineButton.TabIndex = 11;
            nineButton.Text = "9";
            nineButton.UseVisualStyleBackColor = false;
            nineButton.Click += nineButton_Click;
            // 
            // eightButton
            // 
            eightButton.BackColor = Color.White;
            eightButton.Dock = DockStyle.Fill;
            eightButton.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            eightButton.Location = new Point(98, 251);
            eightButton.Name = "eightButton";
            eightButton.Size = new Size(89, 61);
            eightButton.TabIndex = 10;
            eightButton.Text = "8";
            eightButton.UseVisualStyleBackColor = false;
            eightButton.Click += eightButton_Click;
            // 
            // sevenButton
            // 
            sevenButton.BackColor = Color.White;
            sevenButton.Dock = DockStyle.Fill;
            sevenButton.Font = new Font("Trebuchet MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            sevenButton.Location = new Point(3, 251);
            sevenButton.Name = "sevenButton";
            sevenButton.Size = new Size(89, 61);
            sevenButton.TabIndex = 9;
            sevenButton.Text = "7";
            sevenButton.UseVisualStyleBackColor = false;
            sevenButton.Click += sevenButton_Click;
            // 
            // buttonDivide
            // 
            buttonDivide.BackColor = Color.White;
            buttonDivide.Dock = DockStyle.Fill;
            buttonDivide.Font = new Font("Trebuchet MS", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            buttonDivide.Location = new Point(288, 184);
            buttonDivide.Name = "buttonDivide";
            buttonDivide.Size = new Size(91, 61);
            buttonDivide.TabIndex = 8;
            buttonDivide.Text = "/";
            buttonDivide.UseVisualStyleBackColor = false;
            buttonDivide.Click += buttonDivide_Click;
            // 
            // buttonXDivByItself
            // 
            buttonXDivByItself.BackColor = Color.White;
            buttonXDivByItself.Dock = DockStyle.Fill;
            buttonXDivByItself.Font = new Font("Trebuchet MS", 20F, FontStyle.Regular, GraphicsUnit.Point);
            buttonXDivByItself.Location = new Point(193, 184);
            buttonXDivByItself.Name = "buttonXDivByItself";
            buttonXDivByItself.Size = new Size(89, 61);
            buttonXDivByItself.TabIndex = 7;
            buttonXDivByItself.Text = "²√x";
            buttonXDivByItself.UseVisualStyleBackColor = false;
            buttonXDivByItself.Click += buttonXDivByItself_Click;
            // 
            // buttonXUpOn2
            // 
            buttonXUpOn2.BackColor = Color.White;
            buttonXUpOn2.Dock = DockStyle.Fill;
            buttonXUpOn2.Font = new Font("Trebuchet MS", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            buttonXUpOn2.Location = new Point(98, 184);
            buttonXUpOn2.Name = "buttonXUpOn2";
            buttonXUpOn2.Size = new Size(89, 61);
            buttonXUpOn2.TabIndex = 6;
            buttonXUpOn2.Text = "x²";
            buttonXUpOn2.UseVisualStyleBackColor = false;
            buttonXUpOn2.Click += buttonXUpOn2_Click;
            // 
            // button1DivByX
            // 
            button1DivByX.BackColor = Color.White;
            button1DivByX.Dock = DockStyle.Fill;
            button1DivByX.Font = new Font("Trebuchet MS", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            button1DivByX.Location = new Point(3, 184);
            button1DivByX.Name = "button1DivByX";
            button1DivByX.Size = new Size(89, 61);
            button1DivByX.TabIndex = 5;
            button1DivByX.Text = "1/x";
            button1DivByX.UseVisualStyleBackColor = false;
            button1DivByX.Click += button1DivByX_Click;
            // 
            // buttonRemove
            // 
            buttonRemove.BackColor = Color.White;
            buttonRemove.Dock = DockStyle.Fill;
            buttonRemove.Font = new Font("Trebuchet MS", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            buttonRemove.Location = new Point(288, 117);
            buttonRemove.Name = "buttonRemove";
            buttonRemove.Size = new Size(91, 61);
            buttonRemove.TabIndex = 4;
            buttonRemove.Text = "<X";
            buttonRemove.UseVisualStyleBackColor = false;
            buttonRemove.Click += buttonRemove_Click;
            // 
            // buttonC
            // 
            buttonC.BackColor = Color.White;
            buttonC.Dock = DockStyle.Fill;
            buttonC.Font = new Font("Trebuchet MS", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            buttonC.Location = new Point(193, 117);
            buttonC.Name = "buttonC";
            buttonC.Size = new Size(89, 61);
            buttonC.TabIndex = 3;
            buttonC.Text = "C";
            buttonC.UseVisualStyleBackColor = false;
            buttonC.Click += buttonC_Click;
            // 
            // buttonCE
            // 
            buttonCE.BackColor = Color.White;
            buttonCE.Dock = DockStyle.Fill;
            buttonCE.Font = new Font("Trebuchet MS", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            buttonCE.Location = new Point(98, 117);
            buttonCE.Name = "buttonCE";
            buttonCE.Size = new Size(89, 61);
            buttonCE.TabIndex = 2;
            buttonCE.Text = "CE";
            buttonCE.UseVisualStyleBackColor = false;
            buttonCE.Click += buttonCE_Click;
            // 
            // resultTextBox
            // 
            tableLayoutPanel1.SetColumnSpan(resultTextBox, 4);
            resultTextBox.Dock = DockStyle.Fill;
            resultTextBox.Font = new Font("Segoe UI", 47F, FontStyle.Regular, GraphicsUnit.Point);
            resultTextBox.Location = new Point(3, 3);
            resultTextBox.Multiline = true;
            resultTextBox.Name = "resultTextBox";
            resultTextBox.RightToLeft = RightToLeft.Yes;
            resultTextBox.Size = new Size(376, 108);
            resultTextBox.TabIndex = 0;
            // 
            // buttonPercent
            // 
            buttonPercent.BackColor = Color.White;
            buttonPercent.Dock = DockStyle.Fill;
            buttonPercent.Font = new Font("Trebuchet MS", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            buttonPercent.Location = new Point(3, 117);
            buttonPercent.Name = "buttonPercent";
            buttonPercent.Size = new Size(89, 61);
            buttonPercent.TabIndex = 1;
            buttonPercent.Text = "%";
            buttonPercent.UseVisualStyleBackColor = false;
            buttonPercent.Click += buttonPercent_Click;
            // 
            // CalculatorForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 192, 255);
            ClientSize = new Size(382, 520);
            Controls.Add(tableLayoutPanel1);
            MinimumSize = new Size(400, 567);
            Name = "CalculatorForm";
            Text = "Calculator";
            Load += CalculatorForm_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Button buttonResult;
        private Button buttonComma;
        private Button zeroButton;
        private Button buttonPlusSlashMinus;
        private Button buttonMinus;
        private Button threeButton;
        private Button twoButton;
        private Button oneButton;
        private Button buttonPlus;
        private Button sixButton;
        private Button fiveButton;
        private Button fourButton;
        private Button buttonAdd;
        private Button nineButton;
        private Button eightButton;
        private Button sevenButton;
        private Button buttonDivide;
        private Button buttonXDivByItself;
        private Button buttonXUpOn2;
        private Button button1DivByX;
        private Button buttonRemove;
        private Button buttonC;
        private Button buttonCE;
        private TextBox resultTextBox;
        private Button buttonPercent;
    }
}